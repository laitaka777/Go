For more information on Fuego, see http://fuego.sourceforge.net

If Fuego was installed without creating an entry in the start menu or
a shortcut on the desktop, you can run Fuego by clicking on the file
GoGui.exe in this directory. The first time you run it, you need to
register fuego.exe as a Go engine in GoGui by selecting "New Program" from
the "Program" menu, clicking on the browser button next to the command field
and selecting fuego.exe from this directory as the command.
