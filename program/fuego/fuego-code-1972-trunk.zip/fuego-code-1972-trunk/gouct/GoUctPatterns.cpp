//----------------------------------------------------------------------------
/** @file GoUctPatterns.cpp
 See GoUctPatterns.h */
//----------------------------------------------------------------------------

#include "SgSystem.h"
#include "GoUctPatterns.h"

#include <algorithm>
#include "GoBoard.h"
