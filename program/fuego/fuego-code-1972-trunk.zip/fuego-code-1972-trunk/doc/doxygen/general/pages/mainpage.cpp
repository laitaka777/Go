/** @mainpage

    @section generaldoc General Documentation

    Documentation that does not belong to any of the modules:

    - @ref generalportability
    - @ref generalstyle
    - @ref generalautotools
    - @ref generalvisualcplusplus
    - @ref generalmingw
    - @ref generalunittests
    - @ref generalreleases */
