/** @page gonotes Notes for Module Go

@section gonotesinit Initialization

GoInit() / GoFini() must be called before / after using any classes to
initialize global variables.  */
